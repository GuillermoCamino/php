
<?php
function esMayuscula($cadena)
{
    return $cadena === strtoupper($cadena);
}
function esMinuscula($cadena)
{
    return $cadena === strtolower($cadena);
}
?>